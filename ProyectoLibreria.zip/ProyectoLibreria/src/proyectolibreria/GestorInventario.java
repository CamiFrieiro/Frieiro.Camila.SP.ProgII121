package proyectolibreria;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;


public interface GestorInventario <T> {
    
    public void agregarLibro(T libro);
    
    T obtenerLibro (int indice);
    
    void eliminarLibro(int indice);
    
    List <T> filtrarLibros (Predicate <? super T> criterio);  

    void paraCadaElemento (Consumer <? super T> accion);

    
}
