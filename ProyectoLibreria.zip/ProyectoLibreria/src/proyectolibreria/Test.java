package proyectolibreria;

import java.io.IOException;


public class Test {


    public static void main(String[] args) {
        
        try {
            Inventario<Libro> inventarioLibros = new Inventario<>();
            inventarioLibros.agregarLibro(new Libro(1, "1984", "George Orwell",Categoria.ENTRETENIMIENTO));
            inventarioLibros.agregarLibro(new Libro(5, "El señor de los anillos", "J.R.R.Tolkien", Categoria.LITERATURA));
            inventarioLibros.agregarLibro(new Libro(3, "Cien años de soledad", "Gabriel Garcia Marquez", Categoria.LITERATURA));
            inventarioLibros.agregarLibro(new Libro(4, "El origen de las especies", "Charles Darwin", Categoria.CIENCIA));
            inventarioLibros.agregarLibro(new Libro(2, "La guerra de los mundos", "H.G. Wells", Categoria.ENTRETENIMIENTO));

            System.out.println("Inventario de libros:");
            inventarioLibros.paraCadaElemento(p -> {
                System.out.println(p);
            });
            
         // Filtrar libros por categoría LITERATURA
            System.out.println("\nLibros de la categoria LITERATURA:");
            inventarioLibros.filtrarLibros(libro -> libro.getCategoria().equals(Categoria.LITERATURA))
                    .forEach(libro -> System.out.println(libro));
            
        // Filtrar libros cuyo título contiene "1984"
            System.out.println("\nLibros cuyo titulo contiene '1984':");
            inventarioLibros.filtrarLibros(libro -> libro.getTitulo().contains("1984"))
                    .forEach(libro -> System.out.println(libro));

        // Ordenar libros de manera natural (por id)
            System.out.println("\nLibros ordenados de manera natural (por id):");
            inventarioLibros.ordenar();
            inventarioLibros.paraCadaElemento(libro -> System.out.println(libro));

            System.out.println("\nLibros ordenados por título:");
            inventarioLibros.ordenar((libro1, libro2) -> libro1.getTitulo().compareTo(libro2.getTitulo()));
            inventarioLibros.paraCadaElemento(libro -> System.out.println(libro));
            
            
            // Cargar el inventario desde el archivo CSV


        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}

    
    
