package proyectolibreria;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;


public class Inventario <T> implements GestorInventario <T>, Iterable<T>{
    private List<T> libros = new ArrayList<>();
    

    @Override
    public void agregarLibro(T libro) {  
        if(libro == null){
            throw new IllegalArgumentException("No se pueden agregar nulos");
        }
        libros.add(libro);
    }

    @Override
    public T obtenerLibro(int indice) {
        validarIndicesLibros(indice); 
        return libros.get(indice);
    }

    private void validarIndicesLibros(int indice){
        if(indice < 0 || indice >= libros.size()){
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }

    @Override
    public void eliminarLibro(int indice) {
        validarIndicesLibros(indice); 
        libros.remove(indice);
    }


    @Override
    public List<T> filtrarLibros(Predicate<? super T> criterio) {  
        List<T> toReturn = new ArrayList <>(); 
        for(T item: libros){
            if(criterio.test(item)){
                toReturn.add(item);
            }
        }
        return toReturn;
    }
    
    @Override
    public Iterator<T> iterator() {   
        if(!libros.isEmpty() && libros.get(0) instanceof Comparable){
            return iteratorNatural(); 
        }        
        return libros.iterator();
    }
    
    private Iterator<T> iteratorNatural(){
        List<T> aux = new ArrayList<>(libros);
        aux.sort(null);
        return aux.iterator();
    }    
    
    @Override
    public void paraCadaElemento(Consumer<? super T> accion) { 
        for (T item: libros){
            accion.accept(item);
        }
    } 
    
    
    public void ordenar() {
        libros.sort(null); 
    }
    
    public void ordenar(Comparator<? super T> comparator) {
        libros.sort(comparator);
    }    
    
    
    public static void guardarLibrosCSV(List<? extends Libro> lista, String path){ 
        File archivo = new File(path);
        try{
            if(archivo.exists()){
                System.out.println("El Archivo ya existe");
            }else{
                archivo.createNewFile();
            }
        }catch (IOException ex){
            System.out.println("Error. No se puede crear el Archivo");
        }
        
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))){
            bw.write("id, titulo, autor, categoria\n");
            for(Libro libro: lista){
                bw.write(libro.toCSV() + "\n");
            }
            
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }   
    }
    
    public static List<Libro> cargarLibrosCSV(String path){ 
        List<Libro> toReturn = new ArrayList<>();
        try(BufferedReader bf = new BufferedReader(new FileReader(path))){
            String linea;            
            bf.readLine();
            while((linea = bf.readLine()) != null){
                if(linea.endsWith("\n")){
                    linea.substring(linea.length()-1);
                }
                String[] data = linea.split(",");
                
                if (data.length == 4){
                    int id = Integer.parseInt(data[0]);
                    String titulo = data[1];
                    String autor = data[2];
                    Categoria categoria = Categoria.valueOf(data[3]);
                    Libro l = new Libro(id, titulo, autor, categoria);
                    toReturn.add(l);
                }
            }
        }catch(IOException ex){
            System.out.println(ex.getMessage());
            throw new RuntimeException("Problema al cargar libros");
        }
        return toReturn;
    }
    
    
}
    
    
