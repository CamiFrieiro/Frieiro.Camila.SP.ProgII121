package proyectolibreria;

import proyectolibreria.Categoria;


public class Libro implements CSVSerizalizable, Comparable<Libro>{
    
    private int id;
    private String titulo;
    private String autor;
    private Categoria categoria;

    public Libro(int id, String titulo, String autor, Categoria categoria) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public String getTitulo() {
        return titulo;
    }

    @Override
    public int compareTo (Libro otroLibro){
        return Integer.compare(id, otroLibro.id);
    }
    
    @Override
    public String toString() {
        return "Libro{" + "id=" + id + ", titulo=" + titulo + ", autor=" + autor + ", categoria=" + categoria + '}';
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + autor + "," + categoria.name();     }

    
}
