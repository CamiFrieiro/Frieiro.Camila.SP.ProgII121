package proyectolibreria;


public interface CSVSerizalizable {
    
    String toCSV();
    
}
